import React, { useEffect, useState } from 'react';
import './App.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faCaretUp,
  faCaretDown,
  faMinusCircle
} from '@fortawesome/free-solid-svg-icons';
import { faPlay } from '@fortawesome/free-solid-svg-icons';
import { faStop } from '@fortawesome/free-solid-svg-icons';
import { Stomp } from "@stomp/stompjs";
import SockJS from 'sockjs-client';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import fruitables from './data.json'

export default function App() {
  // initializing useState's
  const [newdata, setnewData] = useState(fruitables);
  const [stompClient, setStompClient] = useState(null);
  const [connected, setConnected] = useState(false);
  const [messages, setMessages] = useState([]);
  const [data, setData] = useState([]);
  const [filterData, setFilterData] = useState([]);
  const [graphDataArray, setGraphDataArray] = useState([]);

  // initial useEffect, triggers when component is mounted
  useEffect(() => {
    setConnected(false);
    setMessages([]);
  }, []);

  // this triggers if connected, data, graphDataArray states are updated
  useEffect(() => {
    if (connected) {
      let timeoutId = setTimeout(() => {
        const dataInTable = data.slice(-3);
        if (dataInTable.length === 3) {
          let applePrice, bananaPrice, papayaPrice;

          dataInTable.forEach(item => {
            if (item.name === 'apple') {
              applePrice = item.current_price;
            } else if (item.name === 'banana') {
              bananaPrice = item.current_price;
            } else if (item.name === 'papaya') {
              papayaPrice = item.current_price;
            }
          });

          let new_time = dataInTable[0].time;
          if (new_time) {
            new_time = new_time.slice(11, 19);
          }

          const graphData = {
            new_time: new_time || dataInTable[0].time,
            apple_price: applePrice || 0,
            banana_price: bananaPrice || 0,
            papaya_price: papayaPrice || 0,
          };

          setGraphDataArray(prevData => [...prevData, graphData]);
          console.log(graphDataArray);
        }
      }, 9850);

      return () => clearTimeout(timeoutId);
    }
  }, [connected, data, graphDataArray]);

  // Connect function(triggered when clicked on Start button)
  function connect() {
    const socket = new SockJS('http://localhost:8080/websocket-example');
    const client = Stomp.over(socket);
    client.connect({}, (frame) => {
      setStompClient(client);
      setConnected(true);
      console.log('Connected: ' + frame);
      client.subscribe('/topic/user', (greeting) => {
        const receivedRecord = JSON.parse(greeting.body);
        console.log('Received Record: ', receivedRecord);
        setData(prevData => [...prevData, receivedRecord]);
        showGreeting(receivedRecord);
      });
    });
  }

  // Disconnect function(triggers when clicked on Stop button)
  function disconnect() {
    if (stompClient !== null) {
      stompClient.disconnect();
    }
    setStompClient(null);
    setConnected(false);
    console.log('Disconnected');
  }

  function showGreeting(record) {
    setMessages([...messages, record]);
  }

  // Table Styles
  const table1Style = {
    borderCollapse: 'collapse',
    width: '100%',
  };

  const table1HeaderStyle = {
    border: '1px solid black',
    padding: '8px',
    backgroundColor: '#f2f2f2',
    textAlign: 'center',
  };

  const table1CellStyle = {
    border: '1px solid black',
    padding: '8px',
    textAlign: 'center',
  };

  // Slicing data to show in table
  const dataInTable = data.slice(-3);

  // Slicing data to show in the Graph
  const dataToShow = graphDataArray.slice(-10);

  // Graph function rendered in return
  const Graph = () => {
    return (
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={dataToShow}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="new_time" />
          <YAxis />
          <Tooltip />
          <Legend
            iconSize={20}
            wrapperStyle={{ fontSize: '14px', color: 'blue' }}
            layout="horizontal"
            payload={[
              { value: 'Apple', type: 'line', color: 'red' },
              { value: 'Banana', type: 'line', color: 'darkgreen' },
              { value: 'Papaya', type: 'line', color: 'orange' },
            ]}
          />
          <Line type="monotone" dataKey="apple_price" stroke="red" activeDot={{ r: 8 }} />
          <Line type="monotone" dataKey="banana_price" stroke="darkgreen" activeDot={{ r: 8 }} />
          <Line type="monotone" dataKey="papaya_price" stroke="orange" activeDot={{ r: 8 }} />
        </LineChart>
      </ResponsiveContainer>
    );
  };

  return (
    <>
      {/* Play, stop buttons */}
      <form className="form-inline" onSubmit={(e) => e.preventDefault()}>
        <div className="form-group">
          <label htmlFor="connect"></label>
          <button
            id="connect"
            className='start btn-green'
            type="button"
            onClick={connect}
            disabled={connected}
          >
            <FontAwesomeIcon icon={faPlay} />
            {' '}
            Connect
          </button>
          <button
            id="disconnect"
            className="stop btn-red"
            type="button"
            onClick={disconnect}
            disabled={!connected}
          >
            <FontAwesomeIcon icon={faStop} /> {'Stop'}
          </button>
        </div>
      </form>

      {/* Status Text (Live or not) */}
      <div className="status-container">
        {connected ? (
          <span className="status-text blink">App is Live (Wait for results!)</span>
        ) : (
          <span className="status-text blink">App is Offline (Click on connect to go live!)</span>
        )}
      </div>

      <br />

      {/* Heading */}
      <div>
        <center>
          <h2> Fruitables Demo Price Analysis </h2>
        </center>
      </div>

      {/* Table */}
      <center>
        <table1 style={table1Style}>
          <thead>
            <tr>
              <th style={table1HeaderStyle}>Fruitable Name</th>
              <th style={table1HeaderStyle}>Current Price</th>
              <th style={table1HeaderStyle}>Price Change(in %)</th>
              <th style={table1HeaderStyle}>Previous Price</th>
            </tr>
          </thead>
          <tbody>
            {dataInTable.map((item, index) => {
              if (!item || item.name === undefined) {
                return null;
              }
              return (
                <tr key={index}>
                  <td style={table1CellStyle}>{item.name}</td>
                  <td style={table1CellStyle}>{item.current_price}</td>
                  <td style={table1CellStyle}>
                    <span style={{ color: item.color }}>
                      {item.price_change + " "}
                    </span>
                    {
                      item.price_change[0] === '-' ? (
                        <FontAwesomeIcon icon={faCaretDown} style={{ color: item.color }} />
                      ) : (
                        item.price_change[0] === '0' ? (
                          <FontAwesomeIcon icon={faMinusCircle} style={{ color: item.color }} />
                        ) : (
                          <FontAwesomeIcon icon={faCaretUp} style={{ color: item.color }} />
                        )
                      )
                    }
                  </td>
                  <td style={table1CellStyle}>{item.prev_price}</td>
                </tr>
              );
            })}

          </tbody>
        </table1>
      </ center>
      <br />
      <br />
      <br />

      {/* Graph component */}
      <Graph />
    </>
  );
}