// import React, { useState, useEffect } from 'react';
// import { Client, Stomp } from "@stomp/stompjs";
// import SockJS from 'sockjs-client';

// function App() {
//   const [stompClient, setStompClient] = useState(null);
//   const [connected, setConnected] = useState(false);
//   const [name, setName] = useState('');
//   const [messages, setMessages] = useState([]);

//   useEffect(() => {
//     setConnected(false);
//     setMessages([]);
//   }, []);

//   function connect() {
//     const socket = new SockJS('http://localhost:8080/websocket-example');
//     console.log(socket)
//     const client = Stomp.over(socket);
//     client.connect({}, (frame) => {
//       setStompClient(client);
//       setConnected(true);
//       console.log('Connected: ' + frame);
//       client.subscribe('/topic/user', (greeting) => {
//         const receivedRecord = JSON.parse(greeting.body);
//         console.log('Received Record: ', receivedRecord);
//         // showGreeting(JSON.parse(greeting.body).content);
//         // showGreeting(receivedRecord.name);
//         showGreeting(receivedRecord.name);
//       });
//     });
//   }

//   function disconnect() {
//     if (stompClient !== null) {
//       stompClient.disconnect();
//     }
//     setStompClient(null);
//     setConnected(false);
//     console.log('Disconnected');
//   }

//   // function sendName() {
//   //   if (stompClient) {
//   //     stompClient.send('/app/user', {}, JSON.stringify({ name: name }));
//   //   }
//   // }

//   function showGreeting(message) {
//     console.log(message)
//     setMessages([...messages, message]);
//   }

//   return (
//     <div className="container">
//       <div className="row">
//         <div className="col-md-6">
//           <form className="form-inline" onSubmit={(e) => e.preventDefault()}>
//             <div className="form-group">
//               <label htmlFor="connect">WebSocket connection:</label>
//               <button
//                 id="connect"
//                 className="btn btn-default"
//                 type="button"
//                 onClick={connect}
//                 disabled={connected}
//               >
//                 Connect
//               </button>
//               <button
//                 id="disconnect"
//                 className="btn btn-default"
//                 type="button"
//                 onClick={disconnect}
//                 disabled={!connected}
//               >
//                 Disconnect
//               </button>
//             </div>
//           </form>
//         </div>
//         <div className="col-md-6">
//           <form className="form-inline" onSubmit={(e) => e.preventDefault()}>
//             <div className="form-group">
//               <label htmlFor="name">What is your name?</label>
//               <input
//                 type="text"
//                 id="name"
//                 className="form-control"
//                 placeholder="Your name here..."
//                 value={name}
//                 onChange={(e) => setName(e.target.value)}
//               />
//             </div>
//             {/* <button
//               id="send"
//               className="btn btn-default"
//               type="submit"
//               onClick={sendName}
//               disabled={!connected}
//             >
//               Send
//             </button> */}
//           </form>
//         </div>
//       </div>
//       <div className="row">
//         <div className="col-md-12">
//           <table className="table table-striped">
//             <thead>
//               <tr>
//                 <th>Results</th>
//               </tr>
//             </thead>
//             <tbody>
//               {messages.map((message, index) => (
//                 <tr key={index}>
//                   <td>{message}</td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       </div>
//       <br />
//       <br />
//     </div>
//   );
// }

// export default App;


//  ------------------------------Working code below ------------------------------






// import React, { useState, useEffect } from 'react';
// import { Stomp } from "@stomp/stompjs";
// import SockJS from 'sockjs-client';

// function App() {
//   const [stompClient, setStompClient] = useState(null);
//   const [connected, setConnected] = useState(false);
//   const [messages, setMessages] = useState([]);
//   const [data, setData] = useState([]);

//   useEffect(() => {
//     setConnected(false);
//     setMessages([]);
//   }, []);

//   function connect() {
//     const socket = new SockJS('http://localhost:8080/websocket-example');
//     const client = Stomp.over(socket);
//     client.connect({}, (frame) => {
//       setStompClient(client);
//       setConnected(true);
//       console.log('Connected: ' + frame);
//       client.subscribe('/topic/user', (greeting) => {
//         const receivedRecord = JSON.parse(greeting.body);
//         console.log('Received Record: ', receivedRecord);
//         if (receivedRecord.content === 'No update yet'){
//             setData([...data, receivedRecord]);
//         }
//         console.log(data);
//         showGreeting(receivedRecord);
//       });
//     });
//   }

//   function disconnect() {
//     if (stompClient !== null) {
//       stompClient.disconnect();
//     }
//     setStompClient(null);
//     setConnected(false);
//     console.log('Disconnected');
//   }

//   function showGreeting(record) {
//     // console.log(record);
//     setMessages([...messages, record]);
//   }

//   return (
//     <div className="container">
//       <div className="row">
//         <div className="col-md-6">
//           <form className="form-inline" onSubmit={(e) => e.preventDefault()}>
//             <div className="form-group">
//               <label htmlFor="connect">WebSocket connection:</label>
//               <button
//                 id="connect"
//                 className="btn btn-default"
//                 type="button"
//                 onClick={connect}
//                 disabled={connected}
//               >
//                 Connect
//               </button>
//               <button
//                 id="disconnect"
//                 className="btn btn-default"
//                 type="button"
//                 onClick={disconnect}
//                 disabled={!connected}
//               >
//                 Disconnect
//               </button>
//             </div>
//           </form>
//         </div>
//       </div>
//       <div className="row">
//         <div className="col-md-12">
//           <table className="table table-striped">
//             <thead>
//               <tr>
//                 <th>Name</th>
//                 <th>Time</th>
//                 <th>Color</th>
//                 {/* Add more table headers for other attributes */}
//               </tr>
//             </thead>
//             <tbody>
//               {messages.map((message, index) => (
//                 <tr key={index}>
//                   <td>{message.name}</td>
//                   <td>{message.time}</td>
//                   <td>{message.color}</td>
//                   {/* Display other attributes in respective columns */}
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default App;
// ===========================================  working code above =========================================



import React, { useState, useEffect } from 'react';
import { Stomp } from "@stomp/stompjs";
import SockJS from 'sockjs-client';

function WebSocketConnect() {
  const [stompClient, setStompClient] = useState(null);
  const [connected, setConnected] = useState(false);
  const [messages, setMessages] = useState([]);
  const [data, setData] = useState([]);

  useEffect(() => {
    setConnected(false);
    setMessages([]);
  }, []);

  function connect() {
    const socket = new SockJS('http://localhost:8080/websocket-example');
    const client = Stomp.over(socket);
    client.connect({}, (frame) => {
      setStompClient(client);
      setConnected(true);
      console.log('Connected: ' + frame);
      client.subscribe('/topic/user', (greeting) => {
        const receivedRecord = JSON.parse(greeting.body);
        console.log('Received Record: ', receivedRecord);
        setData(prevData => [...prevData, receivedRecord]);
        showGreeting(receivedRecord);
      });
    });
  }

  function disconnect() {
    if (stompClient !== null) {
      stompClient.disconnect();
    }
    setStompClient(null);
    setConnected(false);
    console.log('Disconnected');
  }

  function showGreeting(record) {
    setMessages([...messages, record]);
  }

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-6">
          <form className="form-inline" onSubmit={(e) => e.preventDefault()}>
            <div className="form-group">
              <label htmlFor="connect">WebSocket connection:</label>
              <button
                id="connect"
                className="btn btn-default"
                type="button"
                onClick={connect}
                disabled={connected}
              >
                Connect
              </button>
              <button
                id="disconnect"
                className="btn btn-default"
                type="button"
                onClick={disconnect}
                disabled={!connected}
              >
                Disconnect
              </button>
            </div>
          </form>
        </div>
      </div>
      <div className="row">
        <div className="col-md-12">
          <table className="table table-striped">
            <thead>
              <tr>
                <th>Name</th>
                <th>Time</th>
                <th>Color</th>
                {/* Add more table headers for other attributes */}
              </tr>
            </thead>
            <tbody>
              {messages.map((message, index) => (
                <tr key={index}>
                  <td>{message.name}</td>
                  <td>{message.time}</td>
                  <td>{message.color}</td>
                  {/* Display other attributes in respective columns */}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {console.log(data)}
      <div className="row">
        <div className="col-md-12">
          <h2>Data</h2>
          <ul>
            {data.map((item, index) => (
              <li key={index}>{JSON.stringify(item)}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default WebSocketConnect;






// import React, { useEffect } from 'react';
// import SockJS from 'sockjs-client';
// import { Stomp } from '@stomp/stompjs';

// function WebSocketExample({ onReceiveRecord }) {
//   useEffect(() => {
//     const socket = new SockJS('http://localhost:8080/websocket-example');
//     const client = Stomp.over(socket);
//     client.connect({}, (frame) => {
//       console.log('Connected: ' + frame);
//       client.subscribe('/topic/user', (greeting) => {
//         const receivedRecord = JSON.parse(greeting.body);
//         console.log('Received Record: ', receivedRecord);
//         onReceiveRecord(receivedRecord); // Pass receivedRecord to the parent component
//       });
//     });
//     return () => {
//       if (client) {
//         client.disconnect();
//       }
//     };
//   }, [onReceiveRecord]);

//   return null; // Since this component does not render anything visible
// }

// export default WebSocketExample;

// ==============================

// import React, { useEffect } from 'react';
// import SockJS from 'sockjs-client';
// import { Stomp } from '@stomp/stompjs';

// function WebSocketExample({ onReceiveRecord }) {
//   useEffect(() => {
//     const socket = new SockJS('http://localhost:8080/websocket-example');
//     const client = Stomp.over(socket);
    
//     const onMessageReceived = (greeting) => {
//       const receivedRecord = JSON.parse(greeting.body);
//       console.log('Received Record: ', receivedRecord);
//       onReceiveRecord(receivedRecord); // Pass receivedRecord to the parent component
//     };

//     client.connect({}, (frame) => {
//       console.log('Connected: ' + frame);
//       client.subscribe('/topic/user', onMessageReceived);
//     });

//     return () => {
//       // Disconnect only when the component is unmounted
//       if (client && client.connected) {
//         client.disconnect();
//         console.log('Disconnected');
//       }
//     };
//   }, [onReceiveRecord]);

//   return null; // Since this component does not render anything visible
// }

// export default WebSocketExample;

